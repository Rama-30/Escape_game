package dataSource;



/*public class SourceDeDonnees {
	Connection connexion;*/

	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.SQLException;
	import java.sql.Statement;

	public class SourceDeDonnees 
	{
		
		private Connection cnx;
		private String driver;
		private String url;
		private String login;
		private String password;
		
		public SourceDeDonnees(String driver, String url, String login, String password) 
		{		
			this.driver = driver;
			this.url = url;
			this.login = login;
			this.password = password;
			
			doConnection();
		}

		
		
		public void doConnection()
		{
			try {
				Class.forName(driver);
				try 
				{
					this.cnx=DriverManager.getConnection(this.url, this.login, this.password);
				} 
				catch (SQLException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
			} 
			catch (ClassNotFoundException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
			
		}
		
		
		public ResultSet DoSearch(String requet)
		{
			ResultSet rs=null;
			try {
				Statement stmt=this.cnx.createStatement();
				rs=stmt.executeQuery(requet);
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return rs;
		}
		
		public Integer Add(String requet)
		{
			Integer nbModifs=null;
			
			try {
				Statement stmt=this.cnx.createStatement();
				nbModifs=stmt.executeUpdate(requet);
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return nbModifs;
			
		}
		
		public PreparedStatement getPreparedStatement(String requet)
		{
			PreparedStatement ps=null;
			
			try {
				ps=this.cnx.prepareStatement(requet);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return ps;
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
				
		
		
		
		

	}
	
	

/*	public void connexionBD() {
		try {
			// Charger le driver JDBC
			Class.forName("com.mysql.cj.jdbc.Driver");

			// Établir la connexion à la base de données
			String url = "jdbc:mysql://localhost:3306/bd_escapegame";
			String utilisateur = "root";
			String motDePasse = "";
			connexion = DriverManager.getConnection(url, utilisateur, motDePasse);

			// Tester la connexion
			if (connexion != null) {
				System.out.println("Connexion à la base de données réussie !");
			} else {
				System.out.println("Erreur lors de la connexion à la base de données.");
			}
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}

	public void ajouter_joueur(String prenom, String nom, String pseudo, String mdp) throws SQLException {

		this.connexionBD();

		String req = "INSERT INTO joueur(prenom, nom, pseudo, password) values(?,?,?,?)";
		PreparedStatement ps = connexion.prepareStatement(req);
		ps.setString(1, prenom);
		ps.setString(2, nom);
		ps.setString(3, pseudo);
		ps.setString(4, mdp);

		ps.executeUpdate();
	}

	public boolean verifier_joueur(String pseudo, String mdp) {

		this.connexionBD();

		boolean res = false;
		try {
			Statement stmt = connexion.createStatement();
			String req = "SELECT * FROM joueur WHERE Pseudo='" + pseudo + "' and MotDePasse='" + mdp + "'";
			ResultSet rs = stmt.executeQuery(req);
			res = rs.next();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return res;
	}

}*/
