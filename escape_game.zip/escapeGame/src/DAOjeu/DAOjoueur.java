package DAOjeu;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;

import player.Joueur;

public class DAOjoueur {

	public DAOjoueur(DataSource sdd, Facade_Biblio fb) {
		super(sdd, fb);
	}

	public Joueur findById(String code) {
		Joueur joueur = null;

		String requete = "SELECT * From ABONNES WHERE Code='" + code + "'";

		ResultSet rs = sdd.DoSearch(requete);
		try (rs) {

			if (rs == null) {
				System.out.println("Problème avec la requête vers les données");
			} else {
				if (rs.next() == false) {
					System.out.println("Pas d'abonné avec ce code");
				} else {
					joueur = this.peuplement(rs);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return joueur;
	}

	public Joueur[] getAll() {
		Joueur[] alljoueur = null;

		String requete = "SELECT * FROM ABONNES ";

		ResultSet rs = sdd.DoSearch(requete);

		if (rs == null) {
			System.err.println("Problème dans la requete " + requete);
		} else {
			try {
				if (rs.next() == false) {
					System.out.println("Aucun abonne présents dans la base");
					alljoueur = null;
				} else {
					alljoueur = this.peuplementMultiple(rs);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return alljoueur;
	}

	public Joueur peuplement(ResultSet rs) throws SQLException {
		Joueur joueur = new Joueur();

		abonne.setNom(rs.getString("Nom"));
		abonne.setPrenom(rs.getString("Prenom"));
		abonne.setCode(rs.getString("Code"));
		abonne.setLogin(rs.getString("login"));
		abonne.setPassword(rs.getString("password"));
		abonne.setAdresse(rs.getString("Adresse"));
		abonne.setEmail(rs.getString("email"));

		Date di = rs.getDate("Date_Inscription");
		
		Date dp = rs.getDate("Date_Penalite");
		if (dp != null)
			abonne.setDate_penalite(dp.toLocalDate());

		//System.err.println("On vient de traiter " + rs.getString("Nom"));
		return joueur;
	}

	public Joueur[] peuplementMultiple(ResultSet rs) {
		Joueur[] res = new Joueur[0];

		try {
			do {
				res = Arrays.copyOf(res, res.length + 1);
				res[res.length - 1] = this.peuplement(rs);
			} while (rs.next() != false);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return res;
	}	

	
	public Boolean creerJoueur(String nom, String prenom, String code, String login, String passawordeee, String email, String adr) {
		Boolean res = false;
		int nbtm = 0; 
		
		LocalDate ddj = LocalDate.now();
		
		String requete="INSERT INTO `abonnes` "
				+ "(`Nom`, `Prenom`, `Code`, `login`, `password`, `Adresse`, `email`, `Date_Inscription`, `Date_Penalite`) "
				+ "VALUES ('"
				+ nom +"','"
				+ prenom + "','"
				+ code + "','"
				+ login + "','"
				+ passawordeee + "','"
				+ adr + "','"
				+ email + "','"
				+ ddj + "',"
				+ "NULL"
				+ ")"
				; 
		
		System.out.println("Requete d'insertion : " + requete);
		nbtm = sdd.Add(requete);
				
		if (nbtm==0) res=false;  // il y a eu un pb dans l'insert
		else res=true;
		
		//if (nbtm==1) res =true;
	
		return res;
	}
