package game;

public class Joueur {

	private String code;
	private String Pseudo;
	private String password;
	
	
	public Joueur(String code, String Pseudo, String password) 
	{
		super();
		this.code = code;
		this.Pseudo = Pseudo;
		this.password = password;
	} 
	
	public Joueur() {}

	@Override
	public String toString() {
		return "Joueur [code=" + code + ", Pseudo=" + Pseudo + ",password=" + password + "]";
	}
	
	public void affiche() {
		System.out.println(this.toString());
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getPseudo() {
		return Pseudo;
	}

	public void setPseudo(String Pseudo) {
		this.Pseudo = Pseudo;
	}


	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	
	
	

}
