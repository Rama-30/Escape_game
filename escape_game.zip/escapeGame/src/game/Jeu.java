package game;

import map.ImageZone;

public class Jeu {
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//ImageZone img=new ImageZone("src/image.JPG");
		//img.displayImage();
		Partie parties = new Partie(); 
		parties.jouer();
		
	}
}
