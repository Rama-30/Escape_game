package map;



import javax.swing.*;
import java.awt.*;

@SuppressWarnings("serial")
public class AffichageImage extends JFrame {

    public AffichageImage() {
        super("Affichage d'image");
        
        // Chargement de l'image
        ImageIcon imageIcon = new ImageIcon("src/image.JPG");
        Image image = imageIcon.getImage();
        
        // Création d'un label pour afficher l'image
        JLabel label = new JLabel(new ImageIcon(image));
        
        // Ajout du label au contenu de la fenêtre
        getContentPane().add(label, BorderLayout.CENTER);
        
        // Taille de la fenêtre
        setSize(500, 500);
        
        // Fermeture de la fenêtre
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
    public static void main(String[] args) {
        AffichageImage fenetre = new AffichageImage();
        fenetre.setVisible(true);
    }
}